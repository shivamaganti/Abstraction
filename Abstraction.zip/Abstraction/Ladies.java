
public class Ladies extends Compartment {

	@Override
	public String notice() {
		
		System.out.println("I am in Ladies Compartment.");
		return null;
	}
}
