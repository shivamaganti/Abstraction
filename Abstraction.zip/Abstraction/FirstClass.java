
public class FirstClass extends Compartment {

	@Override
	public String notice() {
		
		System.out.println("I am in FirstClass Compartment.");
		return null;
	}
	
	

}
