
public class Luggage extends Compartment {

	@Override
	public String notice() {
		System.out.println("I am in Luggage Compartment.");
		return null;
	}

	
}
