
public class General extends Compartment {

	@Override
	public String notice() {
		
		System.out.println("I am in General Compartment.");
		return null;
	}

}
