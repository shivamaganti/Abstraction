
public abstract class Compartment {
	
	public abstract String notice();
	
	public void test() {
		notice();
	}

}
